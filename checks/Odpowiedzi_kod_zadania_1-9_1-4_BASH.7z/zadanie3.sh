#zadanie 3
#Patryk Basko
#=================
#Napisz algorytm za pomocą pseudojęzyka i schematów blokowych. Algorytm ma obliczać
#pole powierzchni i obwód trójkąta prostokątnego. Długości boków przy kącie prostym są
#podawane podczas działania algorytmu.
#=================


let a
let b

echo "hello"
echo "Podaj dlugosc pierwszej przyprostokatnej: "
read a
#echo ""
echo "Podaj dlugosc drugiej przyprostokatnej: "
read b

let trzeci_bok=a**2+b**2
trzeci_bok_1=`echo "sqrt($trzeci_bok)" | bc`
echo "Trzeci bok wynosi: " $trzeci_bok_1

let obwod=a+b+trzeci_bok_1
let pole=(a*b)/2

echo "Obwod wynosi: "$obwod
echo "Pole wynosi: "$pole

read -p "Wcisnij ENTER aby wyjsc z programu"

