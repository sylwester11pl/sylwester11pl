#zadanie 1
#Patryk Basko
#=================
#Napisz algorytm za pomocą pseudojęzyka i schematów blokowych. Algorytm ma wczytywać
#z klawiatury wartości dwóch liczb, obliczać sumę tych liczb i wyświetlać jej wartość na
#ekranie monitora.
#=================


let a
let b


echo "hello"
echo "Podaj pierwsza liczbe: "
read a
#echo ""
echo "Podaj druga liczbe: "
read b

let suma_liczb=$a+$b

echo "Suma twoich liczb wynosi: "$suma_liczb
echo ""
read -p "Wcisnij ENTER aby wyjsc z programu"