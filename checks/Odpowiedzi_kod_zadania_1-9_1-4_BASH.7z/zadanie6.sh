 #zadanie 6
#Patryk Basko
#=================
#Napisz algorytm za pomocą pseudojęzyka i schematów blokowych. Algorytm ma obliczać
#pole i obwód prostokąta o bokach, których wartości są wczytywane podczas działania
#algorytmu.
#=================

echo "Obliczam pole prostokata"
echo "=========================="
echo ""
a=5
b=8
let pole=$a*$b
let obwod=2*$a+2*$b

echo "Pole prostokata o bokach "$a" oraz "$b" wynosi: "$pole
echo "Obwod prostokata o bokach "$a" oraz "$b" wynosi: "$obwod

echo ""
read -p "Wcisnij ENTER aby wyjsc z programu"