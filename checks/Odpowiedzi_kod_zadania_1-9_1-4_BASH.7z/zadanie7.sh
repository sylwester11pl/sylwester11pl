 #zadanie 7
#Patryk Basko
#=================
#Napisz algorytm za pomocą pseudojęzyka i schematów blokowych. Algorytm ma obliczać
#objętość prostopadłościanu. Długości krawędzi są podawane podczas działania programu.
#=================

echo "Obliczam objetosc prostopadloscianiu"
echo "=========================="
echo ""
a=5
b=8
c=12
let objetosc=$a*$b*$c


echo "Objetosc prostopadloscianu o bokach "$a", "$b" oraz "$c" wynosi: "$objetosc


echo ""
read -p "Wcisnij ENTER aby wyjsc z programu"