Do poprawnego działania skryptów zalecam odpalenie na jakiejkolwiek instancji z linuksem. 
Został użyty moduł "bc", którego nie zna chociażby git bash.
Może być również jakieś IDE co obsługuje.