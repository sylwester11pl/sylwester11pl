 #zadanie 8
#Patryk Basko
#=================
#Napisz algorytm za pomocą pseudojęzyka i schematów blokowych. Algorytm ma obliczać
#pole powierzchni i obwód koła.
#=================

echo "Obliczam pole powierzchni oraz obwod kola"
echo "=========================="
echo ""

let r=5
pi=3.14
pole=`echo "scale=2; $pi*($r*$r)" | bc`
obwod=`echo "scale=2; 2*$pi*$r" | bc`

echo "Pole kola o promieniu = "$r" wynosi: "$pole
echo "Obwod kola o promieniu = "$r" wynosi: "$obwod

echo ""
read -p "Wcisnij ENTER aby wyjsc z programu"
