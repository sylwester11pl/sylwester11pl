#zadanie 2
#Patryk Basko
#=================
#Napisz algorytm za pomocą pseudojęzyka i schematów blokowych. Algorytm ma wczytywać
#z klawiatury wartości dwóch liczb oraz wyświetlać w trzech liniach następujące wyniki: w linii
#pierwszej sumę, w linii drugiej różnicę oraz w linii trzeciej iloczyn tych liczb.
#=================


let a
let b


echo "hello"
echo "Podaj pierwsza liczbe: "
read a
#echo ""
echo "Podaj druga liczbe: "
read b

let suma_liczb=$a+$b
let roznica_liczb=$a-$b
let iloczyn_liczb=$a*$b


echo "Suma twoich liczb wynosi: "$suma_liczb
echo ""

echo "Roznica twoich liczb wynosi: "$roznica_liczb
echo ""

echo "Iloczyn twoich liczb wynosi: " $iloczyn_liczb
echo ""
read -p "Wcisnij ENTER aby wyjsc z programu"