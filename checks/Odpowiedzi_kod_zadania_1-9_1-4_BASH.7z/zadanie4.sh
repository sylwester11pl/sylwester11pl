                     
#zadanie 4
#Patryk Basko
#=================
#Napisz algorytm za pomocą pseudojęzyka i schematów blokowych. Algorytm ma obliczać
#średnią arytmetyczną trzech liczb, których wartości są wczytywane podczas działania
#algorytmu. Wynik wyświetl na ekranie monitora.
#=================

let a
let b
let c

echo "hello"
echo "Podaj pierwsza liczbe: "
read a
#echo ""
echo "Podaj druga liczbe: "
read b
echo "Podaj trzecia luczbe: "
read c

srednia=`echo "scale=2; ($a+$b+$c) / 3" | bc `
echo "Srednia arytmetyczna wynosi: "$srednia
echo ""
read -p "Wcisnij ENTER aby wyjsc z programu"
