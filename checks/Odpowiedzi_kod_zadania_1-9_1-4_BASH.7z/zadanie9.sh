
 #zadanie 9
#Patryk Basko
#=================
#Pobrano próbkę wody z pewnego morza. Okazało się, Ŝe w tej wodzie znajduje się 0,012%
#wagowych chlorku sodu. Napisz algorytm, który będzie wczytywał masę wody i podawał ile
#gramów chlorku sodu znajduje się w tej wodzie.
#=================


echo "Podaj wielkosc probki wody (podaj wartosc w ml, np. 100): "
read p
procent=0.012
gram=`echo "scale=2; $p*$procent" | bc`

echo "W pobranej probce wody, waga chlorku sodu wynosi "$gram"g/"$p"ml calego skladu probki."
echo ""
read -p "Wcisnij ENTER aby wyjsc z programu"

