  GNU nano 5.4                                                              zadanie5.sh
#zadanie 5
#Patryk Basko
#=================
#Napisz algorytm za pomocą pseudojęzyka i schematów blokowych. Algorytm ma obliczać
#objętość (V) oraz sumę długości wszystkich krawędzi prostopadłościanu (D). Wartości
#zmiennych a, b, c są podawane podczas działania algorytmu.
#=================

let a
let b
let c

echo "hello"
echo "Podaj pierwsza liczbe: "
read a
#echo ""
echo "Podaj druga liczbe: "
read b
echo "Podaj trzecia liczbe: "
read c

let objetosc=$a*$b*$c
let obwod=4*$a+4*$b+4*$c

echo "Objetosc prostopadloscianu wynosi: "$objetosc
echo "Obwod wynosi: "$obwod

echo ""
read -p "Wcisnij ENTER aby wyjsc z programu"
